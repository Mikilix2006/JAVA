/**
 * 
 */
/**
 * 
 */
module Dibujitos {
	requires java.desktop;
}