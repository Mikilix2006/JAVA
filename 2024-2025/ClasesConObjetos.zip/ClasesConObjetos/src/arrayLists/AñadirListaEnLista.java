package arrayLists;

import java.util.ArrayList;
import java.util.List;

public class AñadirListaEnLista {

	public static void main(String[] args) {
		List <Integer> al=new ArrayList <Integer>();
		List <Integer> al2=new ArrayList <Integer>();
		
		
		
	}

}
