/**
 * 
 */
/**
 * 
 */
module ClasesConObjetoss {
	requires java.desktop;
}