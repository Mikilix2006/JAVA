package objetos;

public class ArrayObjetos {

	public static void main(String[] args) {
		Persona p1=new Persona("Julián");
		Persona p2=new Persona("Ana López",33,true);
		System.out.println(p1);
		System.out.println(p2);
	}

}
